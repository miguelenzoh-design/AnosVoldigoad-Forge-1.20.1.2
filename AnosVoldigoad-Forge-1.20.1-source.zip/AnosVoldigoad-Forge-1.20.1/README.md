# Anos Voldigoad — Forge 1.20.1

Projeto inicial para Minecraft Java 1.20.1, Forge 47.4.5 e Java 17, pensado para PojavLauncher.

## Comandos
- `/anos help` — ajuda.
- `/anos give all` — espada, foco mágico e armadura.
- `/anos give sword` — Venuzdonoa.
- `/anos give magic` — foco mágico.
- `/anos give armor` — conjunto de armadura.
- `/anos power destruction` — magia de destruição em área.
- `/anos power teleport` — teleporte curto para a direção da visão.
- `/anos power regen` — cura e regeneração.
- `/anos power aura` — força, velocidade, salto e visão noturna.
- `/anos power venuzdonoa` — ataque em área inspirado na espada.
- `/anos power reset` — remove efeitos e recupera vida/fome.
- `/anos cooldowns clear` — remove o cooldown do foco mágico.

Use o Foco Mágico de Anos para lançar magia de destruição. O conjunto completo de armadura concede bônus periódicos.

## Compilar no GitHub
1. Envie todo o conteúdo do ZIP para a raiz do repositório, mantendo a pasta `.github`.
2. Abra **Actions** e execute **Build Anos Voldigoad Mod**, ou faça um commit/push.
3. Na execução concluída, baixe o artefato `AnosVoldigoad-Forge-1.20.1`.
4. Extraia o artefato e coloque o `.jar` em `mods` do perfil Forge 1.20.1 no PojavLauncher.

## Importante
Este é um protótipo inicial. As habilidades usam sistemas, efeitos e partículas vanilla para manter o peso baixo. O ZIP contém código-fonte e workflow, não um JAR já compilado. O GitHub Actions precisa compilar o projeto; se falhar, envie o log do erro para corrigirmos antes de instalar.
