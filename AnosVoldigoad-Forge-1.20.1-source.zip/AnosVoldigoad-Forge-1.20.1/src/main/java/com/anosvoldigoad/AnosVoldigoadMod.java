package com.anosvoldigoad;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorItem.Type;
import java.util.List;

@Mod(AnosVoldigoadMod.MODID)
public class AnosVoldigoadMod {
    public static final String MODID = "anosvoldigoad";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Item> VENUZDONOA = ITEMS.register("venuzdonoa",
        () -> new SwordItem(Tiers.NETHERITE, 9, -2.2F, new Item.Properties().fireResistant().stacksTo(1)));
    public static final RegistryObject<Item> ANOS_MAGIC = ITEMS.register("anos_magic",
        () -> new MagicFocusItem(new Item.Properties().stacksTo(1).fireResistant()));
    public static final RegistryObject<Item> ANOS_HELMET = ITEMS.register("anos_helmet",
        () -> new ArmorItem(AnosArmorMaterial.INSTANCE, Type.HELMET, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> ANOS_CHESTPLATE = ITEMS.register("anos_chestplate",
        () -> new ArmorItem(AnosArmorMaterial.INSTANCE, Type.CHESTPLATE, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> ANOS_LEGGINGS = ITEMS.register("anos_leggings",
        () -> new ArmorItem(AnosArmorMaterial.INSTANCE, Type.LEGGINGS, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> ANOS_BOOTS = ITEMS.register("anos_boots",
        () -> new ArmorItem(AnosArmorMaterial.INSTANCE, Type.BOOTS, new Item.Properties().fireResistant()));

    public AnosVoldigoadMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        MinecraftForge.EVENT_BUS.register(this);
    }

    public static class AnosArmorMaterial implements ArmorMaterial {
        public static final AnosArmorMaterial INSTANCE = new AnosArmorMaterial();
        @Override public int getDurabilityForType(Type type) {
            return switch (type) { case BOOTS -> 429; case LEGGINGS -> 495; case CHESTPLATE -> 528; case HELMET -> 363; };
        }
        @Override public int getDefenseForType(Type type) {
            return switch (type) { case BOOTS -> 4; case LEGGINGS -> 7; case CHESTPLATE -> 9; case HELMET -> 4; };
        }
        @Override public int getEnchantmentValue() { return 30; }
        @Override public net.minecraft.sounds.SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.NETHER_STAR); }
        @Override public String getName() { return MODID + ":anos"; }
        @Override public float getToughness() { return 5.0F; }
        @Override public float getKnockbackResistance() { return 0.25F; }
    }

    public static class MagicFocusItem extends Item {
        public MagicFocusItem(Properties properties) { super(properties); }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                AnosPowers.cast(sp, "destruction");
                player.getCooldowns().addCooldown(this, 12);
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    public static class AnosPowers {
        public static void cast(ServerPlayer p, String power) {
            Level level = p.level();
            switch (power.toLowerCase()) {
                case "destruction", "magic" -> {
                    Vec3 center = p.position().add(p.getLookAngle().scale(5)).add(0, 1, 0);
                    AABB area = new AABB(center, center).inflate(4.0);
                    int hits = 0;
                    for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
                        target.hurt(level.damageSources().magic(), 24.0F);
                        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                        hits++;
                    }
                    level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, center.x, center.y, center.z, 60, 1.7, 1.7, 1.7, 0.06);
                    level.playSound(null, p.blockPosition(), SoundEvents.WITHER_BREAK_BLOCK, SoundSource.PLAYERS, 0.8F, 0.7F);
                    p.displayClientMessage(Component.literal("§5Anos: §dMagia de destruição! §7Alvos: " + hits), true);
                }
                case "teleport" -> {
                    Vec3 dest = p.position().add(p.getLookAngle().scale(8));
                    p.teleportTo(dest.x, dest.y, dest.z);
                    level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY()+1, p.getZ(), 35, .7, 1, .7, .25);
                    level.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1, .8F);
                }
                case "regen" -> {
                    p.heal(100.0F);
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 3));
                    p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 2));
                    p.displayClientMessage(Component.literal("§5Anos: §dRegeneração demoníaca!"), true);
                }
                case "aura" -> {
                    p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 4));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 2));
                    p.addEffect(new MobEffectInstance(MobEffects.JUMP, 1200, 2));
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0));
                    p.displayClientMessage(Component.literal("§5Anos: §dAura do Rei Demônio ativada!"), true);
                }
                case "venuzdonoa" -> {
                    Vec3 center = p.position().add(p.getLookAngle().scale(3));
                    for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(5), e -> e != p && e.isAlive())) {
                        target.hurt(level.damageSources().playerAttack(p), 45.0F);
                        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 4));
                    }
                    level.sendParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 65, 2.5, 1.5, 2.5, .12);
                    level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1, .5F);
                    p.displayClientMessage(Component.literal("§5Anos: §dVenuzdonoa — destruição da ordem!"), true);
                }
                case "reset" -> {
                    for (MobEffectInstance effect : List.copyOf(p.getActiveEffects())) p.removeEffect(effect.getEffect());
                    p.setHealth(p.getMaxHealth());
                    p.getFoodData().setFoodLevel(20);
                    p.getCooldowns().removeCooldown(ANOS_MAGIC.get());
                    p.displayClientMessage(Component.literal("§5Anos: §dEstado restaurado."), true);
                }
                default -> p.displayClientMessage(Component.literal("§cPoder desconhecido. Use /anos help"), false);
            }
        }
    }

    @SubscribeEvent public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("anos")
            .then(Commands.literal("help").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal("/anos give <all|sword|magic|armor>"), false);
                ctx.getSource().sendSuccess(() -> Component.literal("/anos power <destruction|teleport|regen|aura|venuzdonoa|reset>"), false);
                ctx.getSource().sendSuccess(() -> Component.literal("/anos cooldowns clear"), false);
                return 1;
            }))
            .then(Commands.literal("power").then(Commands.argument("name", StringArgumentType.word()).executes(ctx -> {
                if (ctx.getSource().getEntity() instanceof ServerPlayer player) {
                    AnosPowers.cast(player, StringArgumentType.getString(ctx, "name")); return 1;
                } return 0;
            })))
            .then(Commands.literal("cooldowns").then(Commands.literal("clear").executes(ctx -> {
                if (ctx.getSource().getEntity() instanceof ServerPlayer player) {
                    player.getCooldowns().removeCooldown(ANOS_MAGIC.get());
                    player.displayClientMessage(Component.literal("§dCooldown da magia removido."), false); return 1;
                } return 0;
            })))
            .then(Commands.literal("give").then(Commands.argument("what", StringArgumentType.word()).executes(ctx -> {
                if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                String what = StringArgumentType.getString(ctx, "what").toLowerCase();
                if (what.equals("all") || what.equals("sword")) player.getInventory().add(VENUZDONOA.get().getDefaultInstance());
                if (what.equals("all") || what.equals("magic")) player.getInventory().add(ANOS_MAGIC.get().getDefaultInstance());
                if (what.equals("all") || what.equals("armor")) {
                    player.getInventory().add(ANOS_HELMET.get().getDefaultInstance());
                    player.getInventory().add(ANOS_CHESTPLATE.get().getDefaultInstance());
                    player.getInventory().add(ANOS_LEGGINGS.get().getDefaultInstance());
                    player.getInventory().add(ANOS_BOOTS.get().getDefaultInstance());
                }
                player.displayClientMessage(Component.literal("§dItens adicionados: " + what), false); return 1;
            })))
            .executes(ctx -> { ctx.getSource().sendSuccess(() -> Component.literal("§5Anos Voldigoad: /anos help"), false); return 1; })
        );
    }

    @SubscribeEvent public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player p = event.player;
        boolean full = p.getItemBySlot(EquipmentSlot.HEAD).is(ANOS_HELMET.get())
            && p.getItemBySlot(EquipmentSlot.CHEST).is(ANOS_CHESTPLATE.get())
            && p.getItemBySlot(EquipmentSlot.LEGS).is(ANOS_LEGGINGS.get())
            && p.getItemBySlot(EquipmentSlot.FEET).is(ANOS_BOOTS.get());
        if (full && p.tickCount % 40 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 80, 2, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 1, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 1, false, false, true));
        }
    }
}
